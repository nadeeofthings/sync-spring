package com.starduct.sync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.stardust.sync.SyncApplication;

@SpringBootTest(classes = SyncApplication.class)
class SyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
