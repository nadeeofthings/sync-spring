package com.stardust.sync.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stardust.sync.core.Constants;
import com.stardust.sync.model.BillingProperties;
import com.stardust.sync.repository.BillingPropertiesRepository;

@Service
public class BillingPropertiesService {
	private static final Logger         LOGGER  = LoggerFactory.getLogger(ConfigurationService.class);
    
    @Autowired
    private BillingPropertiesRepository            billingPropertiesRepository;
    
    
	public List<List<BillingProperties>> getBillingProperties(String ext) {
		List<List<BillingProperties>> propertyList = new ArrayList<List<BillingProperties>>();;
		
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_T_AND_C, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_EMERGENCY_CONTACT, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_BILLING_INQUIRIES, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_NBTAX, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_VATAX, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_PEAK_RATE, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_OFF_PEAK_RATE, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_PENALTY, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_DISCOUNT, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_DUE_DAYS_PERIOD, ext, Constants.FLAG_ENABLED));
		propertyList.add(billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_SERVICE_CHARGE, ext, Constants.FLAG_ENABLED));
		return propertyList;
	}
	
	public List<BillingProperties> getBillingProperty (String key, String ext) {
		return billingPropertiesRepository.findAllByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc( key, ext, Constants.FLAG_ENABLED);
	}
	
	public HashMap<String, String> getMandatoryBillingProperties (String ext) {
		HashMap<String, String> mandatoryBillingProperties = new HashMap<String, String>();
		mandatoryBillingProperties.put(Constants.CONFIG_KEY_T_AND_C, billingPropertiesRepository.findTopByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_T_AND_C, ext, Constants.FLAG_ENABLED).getPropertyValue());
		mandatoryBillingProperties.put(Constants.CONFIG_KEY_EMERGENCY_CONTACT, billingPropertiesRepository.findTopByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_EMERGENCY_CONTACT, ext, Constants.FLAG_ENABLED).getPropertyValue());
		mandatoryBillingProperties.put(Constants.CONFIG_KEY_BILLING_INQUIRIES, billingPropertiesRepository.findTopByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_BILLING_INQUIRIES, ext, Constants.FLAG_ENABLED).getPropertyValue());
		mandatoryBillingProperties.put(Constants.CONFIG_KEY_NBTAX, billingPropertiesRepository.findTopByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_NBTAX, ext, Constants.FLAG_ENABLED).getPropertyValue());
		mandatoryBillingProperties.put(Constants.CONFIG_KEY_VATAX, billingPropertiesRepository.findTopByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_VATAX, ext, Constants.FLAG_ENABLED).getPropertyValue());
		mandatoryBillingProperties.put(Constants.CONFIG_KEY_DUE_DAYS_PERIOD, billingPropertiesRepository.findTopByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_DUE_DAYS_PERIOD, ext, Constants.FLAG_ENABLED).getPropertyValue());
		mandatoryBillingProperties.put(Constants.CONFIG_KEY_SERVICE_CHARGE, billingPropertiesRepository.findTopByPropertyKeyAndExtIgnoreCaseContainingAndEnabledOrderByTimestampDesc(Constants.CONFIG_KEY_SERVICE_CHARGE, ext, Constants.FLAG_ENABLED).getPropertyValue());
		return mandatoryBillingProperties;
	}
	
    
}
