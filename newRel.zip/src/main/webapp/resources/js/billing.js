var elecLogtable, airconLogtable;

$(document).ready(function(){
	$("#dp1").datepicker({
		format: "dd/mm/yyyy",
		todayBtn: "linked",
	    clearBtn: true,
	    orientation: "bottom auto",
	    autoclose: true
		});
	$("#dp2").datepicker({
		format: "dd/mm/yyyy",
	    todayBtn: "linked",
	    clearBtn: true,
	    orientation: "bottom auto",
	    autoclose: true
		});
	$("#dp3").datepicker({
		format: "dd/mm/yyyy",
	    todayBtn: "linked",
	    clearBtn: true,
	    orientation: "bottom auto",
	    autoclose: true
		});
	$("#dp4").datepicker({
		format: "dd/mm/yyyy",
	    todayBtn: "linked",
	    clearBtn: true,
	    orientation: "bottom auto",
	    autoclose: true
		});
	
	$('#EGEN').on('click', function(event) {
		var error = false;
		if(!$('#EFR').val()){
			$('#EFR').addClass('is-invalid');
			error = true;
		}else{
			$('#EFR').removeClass('is-invalid');
		}
		
		if(!$('#ETO').val()){
			$('#ETO').addClass('is-invalid');
			error = true;
		}else{
			$('#ETO').removeClass('is-invalid');
		}
		
		if(!$('#EPP').val()){
			$('#EPP').addClass('is-invalid');
			error = true;
		}else{
			$('#EPP').removeClass('is-invalid');
		}
		
		var SD = $('#EFR').val();
		var parts = SD.split("/");
		var d1 = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
		var ED = $('#ETO').val();
		var parts = ED.split("/");
		var d2 = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
		
		if(d1>=d2) {
			$('#ETOERROR').html('Please select a date later than the start date');
			$('#ETO').addClass('is-invalid');
			error = true;
		}
		
		if(error){
			return false;
		}else{
			var EFL = $('#EFL').val();
			var EFR = $('#EFR').val();
			var ERO = $('#ERO').val();
			var EPP = $('#EPP').val();
			var EDI = $('#EDI').val();
			var EOF = $('#EOF').val();
			var ETO = $('#ETO').val();
			var ERP = $('#ERP').val();
			var EPE = $('#EPE').val();
			var EADJ = $('#EADJ').val();
			if(EADJ=="") EADJ = 0;
			$.ajax({
					type: "GET",
					url: contextPath+"/rest/generateElec?efl="+EFL+"&efr="+EFR+"&ero="+ERO+"&epp="+EPP+"&edi="+EDI+"&eof="+EOF+"&eto="+ETO+"&erp="+ERP+"&epe="+EPE+"&eadj="+EADJ,
					dataType: 'json',
			        complete: function(){
			        	elecLogtable.ajax.reload();
			        }
            });
		}
	
		});
	
	$('#AGEN').on('click', function(event) {
		var error = false;
		if(!$('#AFR').val()){
			$('#AFR').addClass('is-invalid');
			error = true;
		}else{
			$('#AFR').removeClass('is-invalid');
		}
		
		if(!$('#ATO').val()){
			$('#ATO').addClass('is-invalid');
			error = true;
		}else{
			$('#ATO').removeClass('is-invalid');
		}
		
		if(!$('#APP').val()){
			$('#APP').addClass('is-invalid');
			error = true;
		}else{
			$('#APP').removeClass('is-invalid');
		}
		
		var SD = $('#AFR').val();
		var parts = SD.split("/");
		var d1 = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
		var ED = $('#ATO').val();
		var parts = ED.split("/");
		var d2 = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
		
		if(d1>=d2) {
			$('#ATOERROR').html('Please select a date later than the start date');
			$('#ATO').addClass('is-invalid');
			error = true;
		}
		
		if(error){
			return false;
		}else{
			var AFL = $('#AFL').val();
			var AFR = $('#AFR').val();
			var ARO = $('#ARO').val();
			var APP = $('#APP').val();
			var ADI = $('#ADI').val();
			var AOF = $('#AOF').val();
			var ATO = $('#ATO').val();
			var ARP = $('#ARP').val();
			var APE = $('#APE').val();
			var AADJ = $('#AADJ').val();
			if(AADJ=="") AADJ = 0;
			$.ajax({
					type: "GET",
					url: contextPath+"/rest/generateAC?afl="+AFL+"&afr="+AFR+"&aro="+ARO+"&app="+APP+"&adi="+ADI+"&aof="+AOF+"&ato="+ATO+"&arp="+ARP+"&ape="+APE+"&aadj="+AADJ,
					dataType: 'json',
			        complete: function(){
			        	airconLogtable.ajax.reload();
			        }
            });
			
		}
	
		});
	
	$("#EFL").change(function () {
        if($('#EFL').val()=="Ground"){
        	var gOptions = {"KWH 1": "1"};
        	$('#EOFL').html('Meter');
        	var $el = $("#EOF");
        	$el.empty(); // remove old options
        	$.each(gOptions, function(key,value) {
        	  $el.append($("<option></option>")
        	     .attr("value", value).text(key));
        	});
        	
		}else{
			var oOptions = {"One": "1",
      			  "Two": "2",
    			  "Three": "3",
    			  "Four": "4"
    			};
			$('#EOFL').html('Office');
			var $el = $("#EOF");
        	$el.empty(); // remove old options
        	$.each(oOptions, function(key,value) {
        	  $el.append($("<option></option>")
        	     .attr("value", value).text(key));
        	});
		}
    });
	
	$("#AFL").change(function () {
        if($('#AFL').val()=="Ground"){
        	var gOptions = {"BTU 1": "2",
    			  "BTU 2": "3",
    			  "BTU 3": "4"};
        	$('#AOFL').html('Meter');
        	var $el = $("#AOF");
        	$el.empty(); // remove old options
        	$.each(gOptions, function(key,value) {
        	  $el.append($("<option></option>")
        	     .attr("value", value).text(key));
        	});
        	
		}else{
			var oOptions = {"One": "1",
      			  "Two": "2",
    			  "Three": "3",
    			  "Four": "4"
    			};
			$('#AOFL').html('Office');
			var $el = $("#AOF");
        	$el.empty(); // remove old options
        	$.each(oOptions, function(key,value) {
        	  $el.append($("<option></option>")
        	     .attr("value", value).text(key));
        	});
		}
    });

	$.ajax({
		type: "GET",
		url: contextPath+'/rest/getAllBillingProperties?ext=kWh',
		dataType: 'json',
		success: function(data) {
			console.log(data);
			var $el = $("#ERP");//Peak rate
			$el.empty(); // remove old options
			$.each(data[5], function(key,value){
				//console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
			var $el = $("#EDI");//Discount
			$el.empty(); // remove old options
			$.each(data[8], function(key,value){
				console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
			var $el = $("#ERO");//Offpeak rate
			$el.empty(); // remove old options
			$.each(data[6], function(key,value){
				console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
			var $el = $("#EPE");//Offpeak rate
			$el.empty(); // remove old options
			$.each(data[7], function(key,value){
				console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
                       
        },
        complete: function(){}
            });
	$.ajax({
		type: "GET",
		url: contextPath+'/rest/getAllBillingProperties?ext=BTU',
		dataType: 'json',
		success: function(data) {
			console.log(data);
			var $el = $("#ARP");//Peak rate
			$el.empty(); // remove old options
			$.each(data[5], function(key,value){
				//console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
			var $el = $("#ADI");//Discount
			$el.empty(); // remove old options
			$.each(data[8], function(key,value){
				console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
			var $el = $("#ARO");//Offpeak rate
			$el.empty(); // remove old options
			$.each(data[6], function(key,value){
				console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
			var $el = $("#APE");//Offpeak rate
			$el.empty(); // remove old options
			$.each(data[7], function(key,value){
				console.log(value.propertyValue);
				$el.append($("<option></option>").attr("value", value.propertyValue).text(value.propertyValue));
			});
                       
        },
        complete: function(){}
            });
	loadTables();

});

function loadTables() {
	  $.fn.dataTable.moment( "dddd, MMMM Do YYYY, h:mm:ss a" );
		 elecLogtable = $('#elecLog').DataTable( {
		    ajax: {
		        url: contextPath+'/rest/getAllBillingLogs?ext=kWh',
		        dataSrc: function ( json ) {
		            for ( var i=0, ien=json.length ; i<ien ; i++ ) {
			           var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour:'numeric', minute:'numeric', second:'numeric'};
			            var newDate1 = new Date(json[i].timestamp);
			            var newDate2 = new Date(json[i].fromDate);
			            var newDate3 = new Date(json[i].toDate);
		                //json[i].timeStamp= newDate.toLocaleDateString("en-US", options);
			            json[i].timestamp=moment(newDate1).format("dddd, MMMM Do YYYY");
			            json[i].fromDate=moment(newDate2).format("dddd, MMMM Do YYYY");
			            json[i].toDate=moment(newDate3).format("dddd, MMMM Do YYYY");


		              }
		              return json;
		            }
		    },

		    columns: [
	            { "data": "timestamp" },
	            { "data": "billId" },
	            { "data": "id" },
	            { "data": "unit" },
	            { "data": "fromDate" },
	            { "data": "toDate" },
	            {
  					data: null,
  					render: function ( data, type, row ) {
  						console.log(data.billId);
  						if(data.id=='Ground')
  							return '<div class="btn-group  btn-group-sm" role="group" ><button type="button" class="btn btn-dark" onclick="downloadBill(\''+data.billId+'\')">Download</button><button type="button" class="btn btn-danger" onclick="deleteBill(\''+data.billId+'\')">X</button></div>';
  						else
  							return '<div class="btn-group  btn-group-sm" role="group" ><button type="button" class="btn btn-dark" onclick="downloadBill(\''+data.billId+'\')">Download</button><button type="button" class="btn btn-danger" onclick="deleteBill(\''+data.billId+'\')">X</button></div>';
  					}
				}
	        ],
		    order: [[ 0, "desc" ]]
		} );
	  airconLogtable = $('#airconLog').DataTable( {
		    ajax: {
		        url: contextPath+'/rest/getAllBillingLogs?ext=BTU',
		        dataSrc:  function ( json ) {
		            for ( var i=0, ien=json.length ; i<ien ; i++ ) {
			            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour:'numeric', minute:'numeric', second:'numeric'};
			            var newDate1 = new Date(json[i].timestamp);
			            var newDate2 = new Date(json[i].fromDate);
			            var newDate3 = new Date(json[i].toDate);
		                //json[i].timeStamp= newDate.toLocaleDateString("en-US", options);
			            json[i].timestamp=moment(newDate1).format("dddd, MMMM Do YYYY");
			            json[i].fromDate=moment(newDate2).format("dddd, MMMM Do YYYY");
			            json[i].toDate=moment(newDate3).format("dddd, MMMM Do YYYY");
		              }
		              return json;
		            }
		    },
		    columns: [
	            { "data": "timestamp" },
	            { "data": "billId" },
	            { "data": "id" },
	            { "data": "unit" },
	            { "data": "fromDate" },
	            { "data": "toDate" },
	            {
  					data: null,
  					render: function ( data, type, row ) {
  						console.log(data);
  						if(data.id=='Ground')
  							return '<div class="btn-group  btn-group-sm" role="group" ><button type="button" class="btn btn-dark" onclick="downloadBill(\''+data.billId+'\')">Download</button><button type="button" class="btn btn-danger" onclick="deleteBill(\''+data.billId+'\')">X</button></div>';
  						else
  							return '<div class="btn-group  btn-group-sm" role="group" ><button type="button" class="btn btn-dark" onclick="downloadBill(\''+data.billId+'\')">Download</button><button type="button" class="btn btn-danger" onclick="deleteBill(\''+data.billId+'\')">X</button></div>';
  					}
				}
	        ],
		    order: [[ 0, "desc" ]]
		} );
	  //Dirty default set to two weeks
	 // getElecData(id,unit,$("#limitElec")[0].value,$("#fromdatepickelec")[0].value);
	 // getAirconData(id,unit,$("#limitAir")[0].value,$("#fromdatepickair")[0].value);
	}

	function downloadBill(billId) {
			window.open(contextPath+"/billing/downloadBill?billId="+billId);
	}

	function deleteBill(billId) {
			$.ajax({
					type: "GET",
					url: contextPath+"/rest/deleteBill?billId="+billId,
					dataType: 'json',
			        complete: function(){
			        	airconLogtable.ajax.reload();
			        	elecLogtable.ajax.reload();
			        }
            });
		}