package com.stardust.sync.model;

import java.util.List;

import javax.persistence.*;

@Entity
public class Customer {
	
	@Id
	private Integer id;
	private String name;
	private String address;
	private float offPeakRate;
	private float peakRate;
	
	@OneToMany(mappedBy = "customer")
	private List<MeterConfiguration> meterConfigurations;
	
	public Customer() {}
	
	public Customer(Integer id, String name, String address, float offPeakRate, float peakRate,
			List<MeterConfiguration> meterConfigurations) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.offPeakRate = offPeakRate;
		this.peakRate = peakRate;
		this.meterConfigurations = meterConfigurations;
	}

	public float getOffPeakRate() {
		return offPeakRate;
	}

	public void setOffPeakRate(float offPeakRate) {
		this.offPeakRate = offPeakRate;
	}

	public float getPeakRate() {
		return peakRate;
	}

	public void setPeakRate(float peakRate) {
		this.peakRate = peakRate;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
